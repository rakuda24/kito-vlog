import { collection, onSnapshot, deleteDoc, doc } from 'firebase/firestore';
import React, { useEffect, useState } from 'react';
import db from './firebase';

const getStrTime = (time) => {
    let t = new Date(time);
    return (`${t.getFullYear()}/${t.getMonth() + 1}/${t.getDate()} ${t.getHours()}:${t.getMinutes()}:${t.getSeconds()}`);
};

const AllPosts = () => {
    const [posts, setPosts] = useState([]);

    useEffect(() => {
        const unsubscribe = onSnapshot(collection(db, 'posts'), (snapshot) => {
            setPosts(
                snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) // 各投稿にidを追加
                    .sort((a, b) => b.created_at - a.created_at)
            );
        });
        return () => unsubscribe();
    }, []);

    const handleDelete = async (id) => {
        const confirmDelete = window.confirm("削除しますか？");
        if (confirmDelete) {
            try {
                await deleteDoc(doc(db, 'posts', id)); // Firebaseから投稿を削除
                alert("投稿が削除されました。");
            } catch (error) {
                console.log("削除に失敗しました:", error);
            }
        }
    };

    return (
        <div className="all-posts">
            <p>投稿一覧</p>
            {posts.map((post) => (
                <div className="post" key={post.id}>
                    <div className="content">内容：{post.title}</div> {/* タイトルを「内容」として表示 */}
                    <div className="user_name">名前：{post.content}</div> {/* 内容を「名前」として表示 */}
                    <div className="created_at">
                        投稿日：{getStrTime(post.created_at)}
                        <button onClick={() => handleDelete(post.id)} className="delete-button">削除</button>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default AllPosts;
