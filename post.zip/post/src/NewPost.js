import { useState } from "react";
import { collection, addDoc } from "firebase/firestore";
import db from "./firebase";

const NewPost = () => {
    const [content, setContent] = useState(""); // 名前を入力するフィールドとして使用
    const [title, setTitle] = useState("");     // 内容を入力するフィールドとして使用

    const onSubmit = async (e) => {
        e.preventDefault();

        // タイトルまたは名前が空の場合はエラーメッセージを表示
        if (!title || !content) {
            alert("名前と内容の両方を入力してください。");
            return;
        }
        try {
            await addDoc(collection(db, "posts"), {
                title: title,       // 内容
                content: content,   // 名前
                created_at: new Date().getTime()
            });
            setTitle('');
            setContent('');
        } catch (error) {
            console.log(error);
        }
    };

    return (
        <>
            <p>新規投稿</p>
            <form onSubmit={onSubmit}>
                <input
                    type="text"
                    value={content}
                    placeholder="名前"
                    onChange={(e) => setContent(e.target.value)}
                />
                <input
                    type="text"
                    value={title}
                    placeholder="内容"
                    onChange={(e) => setTitle(e.target.value)}
                />
                <button type="submit">投稿</button>
            </form>
        </>
    )
}

export default NewPost;
