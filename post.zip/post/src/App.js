import './App.css';
import NewPost from './NewPost';
import AllPosts from './AllPosts';

function App() {
    return (
        <div className="App">
            <AllPosts />
            <NewPost />
        </div>
    );
}

export default App;
