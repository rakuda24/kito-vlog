// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCPyMmhNKg90zdXCdj0k10Q7pMiTIVw8PY",
  authDomain: "post-a13a7.firebaseapp.com",
  projectId: "post-a13a7",
  storageBucket: "post-a13a7.firebasestorage.app",
  messagingSenderId: "77202861478",
  appId: "1:77202861478:web:23b978f5222c05d1197367"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export default db;